# Complex Cython example with inefficient Python operations
import numpy as np
from libc.math cimport sin, cos, sqrt
import random
import re
import json

def highly_inefficient_function(data, iteration_count=100):
  """This function contains operations that are very difficult for Cython to optimize."""
  
  # Dynamic typing - red flag for Cython
  results = {}
  
  # Recursion - difficult to optimize
  def recursive_process(item, depth):
      if depth <= 0:
          return item
      # String operations - red flag for Cython
      if isinstance(item, str):
          # Regular expressions - red flag for Cython
          return re.sub(r'\d+', lambda m: str(int(m.group(0)) * 2), item)
      elif isinstance(item, (list, tuple)):
          # List comprehension with dynamic typing - red flag
          return [recursive_process(x, depth-1) for x in item]
      elif isinstance(item, dict):
          # Dictionary operations - red flag
          return {k: recursive_process(v, depth-1) for k, v in item.items()}
      else:
          return item
  
  # Eval usage - extreme red flag for Cython
  def unsafe_calculation(expr):
      try:
          return eval(expr)
      except:
          return 0
  
  # Using Python's dir() function - red flag
  dynamic_attributes = dir(data)
  
  for i in range(iteration_count):
      # Converting between Python types - red flag
      key = str(i)
      
      # Unpredictable branching - red flag
      if random.random() > 0.5:
          # JSON operations - red flag
          results[key] = json.dumps({"value": i, "squared": i*i})
      else:
          # Exception handling - red flag
          try:
              # Math with dynamic typing - red flag
              value = data[i % len(data)] if isinstance(data, (list, tuple)) else i
              # String formatting - red flag
              results[key] = f"Value: {value} processed: {sin(float(value))}"
          except Exception as e:
              results[key] = str(e)
  
  # Global namespace operations - red flag
  for i in range(min(5, len(data))):
      item = data[i] if isinstance(data, (list, tuple)) else i
      # Eval with string formatting - extreme red flag
      operation = f"{item} * 2 + {random.random()}"
      results[f"calc_{i}"] = unsafe_calculation(operation)
  
  return results